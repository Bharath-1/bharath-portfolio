import React from 'react'
import { motion } from 'framer-motion'

export default function Skills({ skills = [] }){
  return (
    <section id="skills" className="min-h-screen flex items-center justify-center px-6 py-24">
      <motion.div className="max-w-6xl" initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:0.8}}>
        <h2 className="text-3xl font-bold text-brand-100 mb-6 text-center">Skills</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {skills.map((s,i)=>(
            <motion.div key={i} whileHover={{scale:1.03}} className="p-4 bg-white/8 rounded-2xl border border-white/10 shadow">
              <span className="text-gray-100">{s}</span>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}
