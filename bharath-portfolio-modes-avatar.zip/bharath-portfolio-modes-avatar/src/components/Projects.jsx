import React, { useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

export default function Projects({ projects = [] }){
  const [query, setQuery] = useState('')
  const [tag, setTag] = useState('All')

  const tags = useMemo(() => ['All', ...Array.from(new Set(projects.flatMap(p => p.tags || [])))], [projects])

  const filtered = projects.filter(p => {
    const q = query.toLowerCase()
    const matchQ = !q || p.title.toLowerCase().includes(q) || (p.desc||'').toLowerCase().includes(q)
    const matchT = tag === 'All' || (p.tags||[]).includes(tag)
    return matchQ && matchT
  })

  return (
    <section id="projects" className="min-h-screen flex items-center justify-center bg-white/5 px-6 py-24">
      <div className="max-w-6xl w-full">
        <h2 className="text-3xl font-bold text-brand-100 mb-6 text-center">Projects</h2>
        <div className="flex flex-col md:flex-row items-center justify-between gap-3 mb-6">
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search projects..." className="w-full md:w-1/2 px-4 py-2 rounded-xl bg-white/10 border border-white/10 outline-none" />
          <div className="flex gap-2 flex-wrap">
            {tags.map(t => (
              <button key={t} onClick={()=>setTag(t)} className={`px-3 py-1 rounded-full border ${tag===t?'bg-brand-600 border-brand-600':'bg-white/10 border-white/10'}`}>{t}</button>
            ))}
          </div>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {filtered.map((p,i)=>(
              <motion.a href={p.link||'#'} target="_blank" rel="noreferrer" key={p.title+i}
                initial={{opacity:0,y:20}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:0.4, delay:i*0.05}}
                className="block p-5 rounded-2xl bg-white/8 border border-white/10 hover:bg-white/12 hover:shadow-glass">
                <div className="font-semibold">{p.title}</div>
                <div className="text-gray-300 text-sm mt-1">{p.desc}</div>
                <div className="mt-3 flex gap-2 flex-wrap">
                  {(p.tags||[]).map((t,idx)=>(<span key={idx} className="text-xs px-2 py-0.5 rounded-full bg-white/10 border border-white/10">{t}</span>))}
                </div>
              </motion.a>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  )
}
