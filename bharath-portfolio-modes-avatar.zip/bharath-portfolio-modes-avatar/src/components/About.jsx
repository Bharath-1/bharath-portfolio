import React from 'react'
import { motion } from 'framer-motion'
export default function About({ about }){
  return (
    <section id="about" className="min-h-screen flex items-center justify-center bg-white/5 px-6 py-24">
      <motion.div className="max-w-4xl text-center" initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:0.8}}>
        <h2 className="text-3xl font-bold text-brand-100 mb-4">About Me</h2>
        <p className="text-gray-200 max-w-2xl mx-auto">{about}</p>
      </motion.div>
    </section>
  )
}
