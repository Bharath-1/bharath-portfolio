import React, { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useMode } from './ModeSwitcher'

const texts = {
  hero: "Hi! I'm Bharath. Scroll to see my work.",
  about: "About me: HIL, diagnostics, and automation.",
  skills: "These are the tools and stacks I use.",
  projects: "Browse my featured projects with filters.",
  contact: "Want to collaborate? Reach me below."
}

const videos = {
  hero: "/videos/hero.mp4",
  about: "/videos/about.mp4",
  skills: "/videos/skills.mp4",
  projects: "/videos/projects.mp4",
  contact: "/videos/contact.mp4"
}

export default function ExplainerDock({ name='Bharath' }){
  const { mode } = useMode()
  const [active, setActive] = useState('hero')
  const utterRef = useRef(null)

  useEffect(() => {
    const ids = Object.keys(texts)
    const observers = []
    ids.forEach(id => {
      const el = document.getElementById(id)
      if (!el) return
      const obs = new IntersectionObserver((entries) => {
        entries.forEach(e => {
          if (e.isIntersecting && e.intersectionRatio > 0.45) setActive(id)
        })
      }, { threshold: [0.45] })
      obs.observe(el)
      observers.push(obs)
    })
    return () => observers.forEach(o=>o.disconnect())
  }, [])

  // Voice mode
  useEffect(() => {
    if (mode !== 'voice') return
    try {
      window.speechSynthesis.cancel()
      const u = new SpeechSynthesisUtterance(texts[active])
      u.rate = 1.05; u.pitch = 1.0; u.lang = 'en-US'
      utterRef.current = u
      window.speechSynthesis.speak(u)
    } catch {}
  }, [mode, active])

  const content = (
    <div className="flex gap-3 items-center">
      {mode === 'avatar' && (
        <img src="/images/avatar.jpg" alt="Avatar" className="w-12 h-12 rounded-full object-cover border border-white/10" />
      )}
      {mode === 'video' && (
        <video src={videos[active]} className="w-20 h-12 rounded-lg border border-white/10 bg-black" muted loop autoPlay playsInline onError={(e)=>{e.currentTarget.style.display='none'}} />
      )}
      <div className="text-sm text-gray-100">{texts[active]}</div>
    </div>
  )

  return (
    <div className="pointer-events-none">
      <AnimatePresence mode="wait">
        <motion.div key={active+mode}
          initial={{opacity:0, y:20, scale:0.98}}
          animate={{opacity:1, y:0, scale:1}}
          exit={{opacity:0, y:20, scale:0.98}}
          transition={{duration:0.25}}
          className="fixed right-6 bottom-6 w-72 bg-white/10 border border-white/10 rounded-2xl p-3 shadow-glass backdrop-blur z-50 pointer-events-auto">
          {content}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
