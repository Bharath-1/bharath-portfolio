import React, { useContext, useEffect } from 'react'
import { save, load } from '../utils/storage'
import { ModeContext } from '../App'

export function useMode(){ return useContext(ModeContext) }

export default function ModeSwitcher(){
  const { mode, setMode } = useMode()
  useEffect(()=>{ const st = load(); save({ ...st, mode }) }, [mode])
  return (
    <div className="fixed top-3 right-3 z-50">
      <select
        className="px-3 py-2 rounded-xl bg-white/10 border border-white/10 text-sm"
        value={mode}
        onChange={(e)=>setMode(e.target.value)}
      >
        <option value="avatar">Avatar</option>
        <option value="video">Video</option>
        <option value="voice">Voice</option>
      </select>
    </div>
  )
}
