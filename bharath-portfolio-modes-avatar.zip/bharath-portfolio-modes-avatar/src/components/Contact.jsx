import React from 'react'
import { motion } from 'framer-motion'

export default function Contact({ socials = {}, resume }){
  const { github, linkedin, youtube, email } = socials
  return (
    <section id="contact" className="min-h-screen flex items-center justify-center px-6 py-24">
      <motion.div className="max-w-3xl text-center" initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:0.8}}>
        <h2 className="text-3xl font-bold text-brand-100 mb-4">Contact</h2>
        <div className="text-gray-200 mb-6">Open to collaboration & opportunities.</div>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          {email && <a className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700" href={`mailto:${email}`}>Email Me</a>}
          {linkedin && <a className="px-4 py-2 rounded-xl bg-white/10 border border-white/10" target="_blank" rel="noreferrer" href={linkedin}>LinkedIn</a>}
          {github && <a className="px-4 py-2 rounded-xl bg-white/10 border border-white/10" target="_blank" rel="noreferrer" href={github}>GitHub</a>}
          {youtube && <a className="px-4 py-2 rounded-xl bg-white/10 border border-white/10" target="_blank" rel="noreferrer" href={youtube}>YouTube</a>}
          {resume && <a className="px-4 py-2 rounded-xl bg-white/10 border border-white/10" href={resume} download>Download Resume</a>}
        </div>
      </motion.div>
    </section>
  )
}
