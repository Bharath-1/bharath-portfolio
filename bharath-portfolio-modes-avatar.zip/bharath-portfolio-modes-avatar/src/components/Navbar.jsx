import React from 'react'
export default function Navbar({ name }){
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/10 backdrop-blur border-b border-white/10">
      <div className="max-w-7xl mx-auto flex items-center justify-between p-4 text-sm">
        <div className="text-lg font-bold text-white">{name || 'Bharath'}</div>
        <div className="hidden md:flex gap-6 text-gray-200">
          <a href="#hero" className="hover:text-brand-100">Home</a>
          <a href="#about" className="hover:text-brand-100">About</a>
          <a href="#skills" className="hover:text-brand-100">Skills</a>
          <a href="#projects" className="hover:text-brand-100">Projects</a>
          <a href="#contact" className="hover:text-brand-100">Contact</a>
        </div>
      </div>
    </nav>
  )
}
