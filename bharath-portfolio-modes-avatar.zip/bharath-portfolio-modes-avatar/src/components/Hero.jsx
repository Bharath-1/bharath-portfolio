import React from 'react'
import { motion } from 'framer-motion'

export default function Hero({ name, role, location }){
  return (
    <section id="hero" className="h-screen flex items-center justify-center px-6">
      <motion.div initial={{opacity:0,y:30}} animate={{opacity:1,y:0}} transition={{duration:0.8}} className="max-w-6xl w-full grid md:grid-cols-2 gap-8 items-center">
        <div className="text-center md:text-left">
          <h1 className="text-5xl font-extrabold text-white mb-4">{name || 'Bharath Babu'}</h1>
          <p className="text-lg text-gray-200 mb-2">{role || 'HIL Test Engineer • Automation Specialist'}</p>
          <p className="text-sm text-gray-400">{location || 'Bengaluru, India'}</p>
          <div className="mt-8 inline-flex gap-3">
            <a href="#projects" className="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 shadow-glass">View Projects</a>
            <a href="#contact" className="px-5 py-2 rounded-xl bg-white/10 border border-white/10 hover:bg-white/15">Contact</a>
          </div>
        </div>
        <div className="flex justify-center md:justify-end">
          <div className="relative">
            <img src="/images/avatar.jpg" alt="Avatar" className="w-48 h-48 rounded-full object-cover border-4 border-white/10 shadow-glass" />
            <span className="absolute -bottom-3 left-1/2 -translate-x-1/2 text-xs text-gray-300 bg-white/10 border border-white/10 px-2 py-0.5 rounded-full">Semi‑realistic</span>
          </div>
        </div>
      </motion.div>
    </section>
  )
}
