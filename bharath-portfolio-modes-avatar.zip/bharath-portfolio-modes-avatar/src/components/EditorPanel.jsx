import React, { useEffect, useState } from 'react'
import { save, load, clear } from '../utils/storage'

export default function EditorPanel(){
  const [open, setOpen] = useState(false)
  const [draft, setDraft] = useState(load())

  useEffect(()=>{ setDraft(load()) }, [open])

  const onChange = (field) => (e) => setDraft({ ...draft, [field]: e.target.value })
  const setNested = (cat, field) => (e) => setDraft({ ...draft, [cat]: { ...(draft[cat]||{}), [field]: e.target.value } })
  const onSkillsChange = (e) => setDraft({ ...draft, skills: e.target.value.split(',').map(s=>s.trim()).filter(Boolean) })
  const onProjectsChange = (e) => { try { const arr = JSON.parse(e.target.value); if (Array.isArray(arr)) setDraft({ ...draft, projects: arr }) } catch {} }

  const saveAll = () => { save(draft); window.dispatchEvent(new CustomEvent('portfolio-refresh', { detail: { refresh: true } })); setOpen(false) }
  const reset = () => { clear(); window.dispatchEvent(new CustomEvent('portfolio-refresh', { detail: { refresh: true } })); setOpen(false) }

  return (
    <>
      <button onClick={()=>setOpen(true)} className="fixed left-6 bottom-6 z-50 px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 shadow-glass">Edit</button>
      {open && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="w-full max-w-3xl bg-slate-900 border border-white/10 rounded-2xl p-6 shadow-glass">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold">Edit Portfolio</h3>
              <button onClick={()=>setOpen(false)} className="px-3 py-1 rounded-lg bg-white/10">Close</button>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div><label className="text-sm text-gray-300">Name</label><input defaultValue={draft.name||''} onChange={onChange('name')} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div><label className="text-sm text-gray-300">Role</label><input defaultValue={draft.role||''} onChange={onChange('role')} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div className="md:col-span-2"><label className="text-sm text-gray-300">About</label><textarea defaultValue={draft.about||''} onChange={onChange('about')} rows={3} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div className="md:col-span-2"><label className="text-sm text-gray-300">Skills (comma separated)</label><input defaultValue={(draft.skills||[]).join(', ')} onChange={onSkillsChange} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div><label className="text-sm text-gray-300">GitHub</label><input defaultValue={(draft.socials||{}).github||''} onChange={setNested('socials','github')} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div><label className="text-sm text-gray-300">LinkedIn</label><input defaultValue={(draft.socials||{}).linkedin||''} onChange={setNested('socials','linkedin')} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div><label className="text-sm text-gray-300">YouTube</label><input defaultValue={(draft.socials||{}).youtube||''} onChange={setNested('socials','youtube')} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div><label className="text-sm text-gray-300">Email</label><input defaultValue={(draft.socials||{}).email||''} onChange={setNested('socials','email')} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10" /></div>
              <div className="md:col-span-2"><label className="text-sm text-gray-300">Projects JSON (edit array)</label><textarea defaultValue={JSON.stringify(draft.projects||[], null, 2)} onChange={onProjectsChange} rows={8} className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10 font-mono text-sm" /></div>
            </div>
            <div className="flex gap-3 justify-end mt-4">
              <button onClick={reset} className="px-4 py-2 rounded-xl bg-white/10 border border-white/10">Reset</button>
              <button onClick={saveAll} className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700">Save</button>
            </div>
            <p className="text-xs text-gray-400 mt-2">Edits save to your browser (localStorage). Update src/data/portfolioData.js for permanent changes.</p>
          </div>
        </div>
      )}
    </>
  )
}
