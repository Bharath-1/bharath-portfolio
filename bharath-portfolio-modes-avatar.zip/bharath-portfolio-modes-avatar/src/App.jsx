import React, { useEffect, useMemo, useState } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Contact from './components/Contact'
import Footer from './components/Footer'
import ExplainerDock from './components/ExplainerDock'
import EditorPanel from './components/EditorPanel'
import ModeSwitcher, { useMode } from './components/ModeSwitcher'
import { portfolioData as defaults } from './data/portfolioData'
import { load } from './utils/storage'

export const ModeContext = React.createContext('avatar')

export default function App(){
  const [refresh, setRefresh] = useState(0)
  const stored = useMemo(()=>load(),[refresh])
  const data = useMemo(()=>({...defaults, ...stored,
    socials: {...(defaults.socials||{}), ...(stored.socials||{})},
    projects: stored.projects || defaults.projects,
    skills: stored.skills || defaults.skills
  }),[stored])

  const [mode, setMode] = useState(stored.mode || 'avatar')

  useEffect(()=>{ const h = e => { if(e.detail?.refresh) setRefresh(v=>v+1) }; window.addEventListener('portfolio-refresh', h); return ()=>window.removeEventListener('portfolio-refresh', h)},[])

  return (
    <ModeContext.Provider value={{ mode, setMode }}>
      <Navbar name={data.name} />
      <ModeSwitcher />
      <ExplainerDock name={data.name} />
      <main className="pt-16">
        <Hero name={data.name} role={data.role} location={data.location} />
        <About about={data.about} />
        <Skills skills={data.skills} />
        <Projects projects={data.projects} />
        <Contact socials={data.socials} resume={data.resume} />
        <Footer />
      </main>
      <EditorPanel data={data} />
    </ModeContext.Provider>
  )
}
