export const portfolioData = {
  name: "Bharath Babu",
  role: "HIL Test Engineer • Automation Specialist",
  location: "Bengaluru, India",
  about: "Passionate about ECU testing, diagnostics and automation. 4+ years in HIL, CANoe/CAPL, dSPACE, EXAM and middleware validation.",
  skills: ["HIL Testing","CANoe","CAPL","dSPACE","EXAM","Diagnostics","PSI5","SPI","AUTOSAR","Python","Automation"],
  projects: [
    { title: "AUTOSAR Middleware Validation", desc: "Consolidated middleware testing with SPI & PSI5 interfaces on HIL.", tags: ["AUTOSAR","SPI","PSI5","HIL"], link: "https://github.com/Bharath-1" },
    { title: "Infotainment HIL Testing", desc: "Validation using CANoe, CAPL and diagnostic tools for head units.", tags: ["Infotainment","Diagnostics","CANoe"], link: "https://github.com/Bharath-1" },
    { title: "Automation Framework", desc: "Reusable CAPL + Python automation for ECU regression suites.", tags: ["Automation","CAPL","Python"], link: "https://github.com/Bharath-1" }
  ],
  socials: {
    github: "https://github.com/Bharath-1",
    linkedin: "https://linkedin.com/in/",
    youtube: "https://youtube.com/@",
    email: "your.email@example.com"
  },
  resume: "/resume.pdf"
};
